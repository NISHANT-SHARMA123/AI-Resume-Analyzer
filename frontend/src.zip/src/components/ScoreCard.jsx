// src/components/ScoreCard.jsx
//
// CHANGES IN THIS VERSION:
//   Added a "Score Breakdown" panel between the score hero and the
//   existing analysis grid. Shows 4 animated dimension bars:
//     - Skill Match      (skillScore)
//     - Experience Fit   (experienceScore)
//     - Project Depth    (projectScore)
//     - Resume Quality   (resumeQualityScore)
//
//   All existing content (view toggle, score hero, keywords, feedback,
//   suggestions, summary, ATS charts tab) is completely unchanged.

import { useState } from 'react';
import { ATSCharts } from './ATSCharts';

// ─────────────────────────────────────────────────────────────
//  ScoreDimensionBar
//  A single animated horizontal bar for one score dimension.
//  Shows label, animated fill, and numeric percentage.
// ─────────────────────────────────────────────────────────────
function ScoreDimensionBar({ label, value, color, description }) {
  const pct = Math.round(value ?? 0);
  const barColor = color || (
    pct >= 75 ? '#10b981' :
    pct >= 50 ? '#f59e0b' :
    pct >= 30 ? '#f97316' : '#ef4444'
  );

  return (
    <div style={dim.row}>
      <div style={dim.labelCol}>
        <span style={dim.label}>{label}</span>
        {description && (
          <span style={dim.desc}>{description}</span>
        )}
      </div>
      <div style={dim.barCol}>
        <div style={dim.track}>
          <div style={{
            ...dim.fill,
            width: `${pct}%`,
            background: barColor,
            boxShadow: `0 0 8px ${barColor}50`,
          }} />
        </div>
      </div>
      <div style={{ ...dim.pct, color: barColor }}>{pct}%</div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
//  ScoreBreakdown
//  The 4-dimension breakdown panel.
//  Only renders when at least one sub-score is present.
// ─────────────────────────────────────────────────────────────
function ScoreBreakdown({ result }) {
  // Check if the ML service returned sub-scores (new format)
  const hasSubScores =
    result?.skillScore         != null ||
    result?.experienceScore    != null ||
    result?.projectScore       != null ||
    result?.resumeQualityScore != null;

  if (!hasSubScores) return null;

  const dimensions = [
    {
      label:       'Skill Match',
      key:         'skillScore',
      icon:        '⚡',
      description: 'JD-required skills found in resume',
      color:       '#00f5ff',
    },
    {
      label:       'Experience Fit',
      key:         'experienceScore',
      icon:        '💼',
      description: 'Relevance of work history to role',
      color:       '#a855f7',
    },
    {
      label:       'Project Depth',
      key:         'projectScore',
      icon:        '🔧',
      description: 'Project evidence and tech-stack overlap',
      color:       '#10b981',
    },
    {
      label:       'Resume Quality',
      key:         'resumeQualityScore',
      icon:        '📋',
      description: 'Structure, ATS-friendliness, action verbs',
      color:       '#f59e0b',
    },
  ];

  // Compute weighted composite to display alongside the overall score
  const validDims  = dimensions.filter(d => result[d.key] != null);
  const composite  = validDims.length > 0
    ? Math.round(validDims.reduce((sum, d) => sum + (result[d.key] || 0), 0) / validDims.length)
    : null;

  return (
    <div style={dim.panel}>
      {/* Panel header */}
      <div style={dim.header}>
        <h4 style={dim.title}>📊 Score Breakdown</h4>
        {composite != null && (
          <span style={{
            ...dim.compositeBadge,
            color: composite >= 70 ? '#10b981' : composite >= 50 ? '#f59e0b' : '#ef4444',
            borderColor: composite >= 70 ? 'rgba(16,185,129,0.3)' : composite >= 50 ? 'rgba(245,158,11,0.3)' : 'rgba(239,68,68,0.3)',
            background: composite >= 70 ? 'rgba(16,185,129,0.08)' : composite >= 50 ? 'rgba(245,158,11,0.08)' : 'rgba(239,68,68,0.08)',
          }}>
            Avg {composite}%
          </span>
        )}
      </div>

      {/* Dimension bars */}
      <div style={dim.barsContainer}>
        {dimensions.map(d => (
          <ScoreDimensionBar
            key={d.key}
            label={`${d.icon} ${d.label}`}
            value={result[d.key]}
            color={d.color}
            description={d.description}
          />
        ))}
      </div>

      {/* Interpretation tip — only shown if score is low */}
      {composite != null && composite < 50 && (
        <div style={dim.tip}>
          💡 <strong>Tip:</strong> Focus on the dimensions with the lowest scores.
          Adding missing skills and strengthening project descriptions typically
          has the highest impact on your overall match.
        </div>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
//  ScoreCard — main export (existing structure preserved)
// ─────────────────────────────────────────────────────────────
export default function ScoreCard({ result }) {
  const [activeView, setActiveView] = useState('analysis'); // 'analysis' | 'charts'

  const score       = Math.round(result?.matchScore || 0);
  const keywords    = result?.keywordsMatched?.split(',').filter(Boolean) || [];
  const missing     = result?.missingKeywords?.split(',').filter(Boolean)  || [];
  const feedback    = result?.feedbackPoints?.split('\n').filter(Boolean)  || [];
  const suggestions = result?.improvementSuggestions?.split('\n').filter(Boolean) || [];

  const getScoreColor = (s) => {
    if (s >= 80) return '#10b981';
    if (s >= 60) return '#f59e0b';
    if (s >= 40) return '#f97316';
    return '#ef4444';
  };
  const color = getScoreColor(score);

  const getScoreLabel = (s) => {
    if (s >= 80) return 'Excellent Match';
    if (s >= 60) return 'Good Match';
    if (s >= 40) return 'Fair Match';
    return 'Needs Work';
  };

  return (
    <div style={styles.wrapper}>

      {/* ── View Toggle (unchanged) ── */}
      <div style={styles.viewToggle}>
        <button
          style={{ ...styles.toggleBtn, ...(activeView === 'analysis' ? styles.toggleActive : {}) }}
          onClick={() => setActiveView('analysis')}>
          📋 Analysis
        </button>
        <button
          style={{ ...styles.toggleBtn, ...(activeView === 'charts' ? styles.toggleActive : {}) }}
          onClick={() => setActiveView('charts')}>
          📊 ATS Charts
        </button>
      </div>

      {/* ── Score Hero (unchanged) ── */}
      <div style={styles.scoreHero}>
        <div style={{ ...styles.scoreRing, borderColor: color, boxShadow: `0 0 40px ${color}40` }}>
          <div style={{ ...styles.scoreNum, color }}>{score}%</div>
          <div style={{ ...styles.scoreLabel, color }}>{getScoreLabel(score)}</div>
        </div>
        <div style={styles.scoreMeta}>
          <h3 style={styles.metaTitle}>ATS Match Score</h3>
          <p style={{ color: '#64748b', fontSize: '0.9rem', lineHeight: 1.7 }}>
            Your resume matches <strong style={{ color }}>{score}%</strong> of the job requirements.
            {score >= 70
              ? ' Great job — you are a strong candidate!'
              : ' Consider adding more relevant keywords and skills.'}
          </p>
          <div style={styles.progressBar}>
            <div style={{ ...styles.progressFill, width: `${score}%`, background: color }} />
          </div>
        </div>
      </div>

      {/* ── NEW: Score Breakdown (only in analysis tab) ── */}
      {activeView === 'analysis' && (
        <ScoreBreakdown result={result} />
      )}

      {/* ── ANALYSIS VIEW (unchanged) ── */}
      {activeView === 'analysis' && (
        <div style={styles.grid}>
          {/* Keywords Matched */}
          <div style={styles.card}>
            <h4 style={{ ...styles.cardTitle, color: '#10b981' }}>✅ Keywords Matched</h4>
            <div style={styles.tagRow}>
              {keywords.length > 0
                ? keywords.map((k, i) => (
                    <span key={i} style={{ ...styles.tag, borderColor: '#10b98140', color: '#10b981' }}>
                      {k.trim()}
                    </span>
                  ))
                : <p style={styles.empty}>No matched keywords found</p>
              }
            </div>
          </div>

          {/* Missing Keywords */}
          <div style={styles.card}>
            <h4 style={{ ...styles.cardTitle, color: '#ef4444' }}>❌ Missing Keywords</h4>
            <div style={styles.tagRow}>
              {missing.length > 0
                ? missing.map((k, i) => (
                    <span key={i} style={{ ...styles.tag, borderColor: '#ef444440', color: '#ef4444' }}>
                      {k.trim()}
                    </span>
                  ))
                : <p style={styles.empty}>No missing keywords found!</p>
              }
            </div>
          </div>

          {/* AI Feedback */}
          <div style={{ ...styles.card, gridColumn: '1 / -1' }}>
            <h4 style={{ ...styles.cardTitle, color: '#00f5ff' }}>🤖 AI Feedback</h4>
            <ul style={styles.feedbackList}>
              {feedback.length > 0
                ? feedback.map((f, i) => (
                    <li key={i} style={styles.feedbackItem}>
                      <span style={styles.bullet}>›</span>
                      <span style={{ color: '#94a3b8' }}>{f.replace(/^[-•*]\s*/, '')}</span>
                    </li>
                  ))
                : <p style={styles.empty}>No feedback available</p>
              }
            </ul>
          </div>

          {/* Improvement Suggestions */}
          <div style={{ ...styles.card, gridColumn: '1 / -1' }}>
            <h4 style={{ ...styles.cardTitle, color: '#a855f7' }}>💡 Improvement Suggestions</h4>
            <ul style={styles.feedbackList}>
              {suggestions.length > 0
                ? suggestions.map((s, i) => (
                    <li key={i} style={styles.feedbackItem}>
                      <span style={{ ...styles.bullet, color: '#a855f7' }}>›</span>
                      <span style={{ color: '#94a3b8' }}>{s.replace(/^[-•*\d.]\s*/, '')}</span>
                    </li>
                  ))
                : <p style={styles.empty}>No suggestions available</p>
              }
            </ul>
          </div>

          {/* Resume Summary */}
          {result?.summary && (
            <div style={{ ...styles.card, gridColumn: '1 / -1' }}>
              <h4 style={{ ...styles.cardTitle, color: '#f59e0b' }}>📄 Resume Summary</h4>
              <p style={{ color: '#94a3b8', fontSize: '0.95rem', lineHeight: 1.8 }}>
                {result.summary}
              </p>
            </div>
          )}
        </div>
      )}

      {/* ── CHARTS VIEW (unchanged) ── */}
      {activeView === 'charts' && (
        <ATSCharts result={result} />
      )}

    </div>
  );
}

// ─────────────────────────────────────────────────────────────
//  STYLES — existing styles unchanged, new dim styles added
// ─────────────────────────────────────────────────────────────
const styles = {
  wrapper: { display: 'flex', flexDirection: 'column', gap: '20px' },

  viewToggle: {
    display: 'flex', gap: '4px',
    background: 'rgba(255,255,255,0.02)',
    border: '1px solid rgba(255,255,255,0.07)',
    borderRadius: '12px', padding: '4px',
    alignSelf: 'flex-start',
  },
  toggleBtn: {
    padding: '9px 20px',
    background: 'transparent', border: 'none',
    borderRadius: '9px', color: '#64748b',
    fontFamily: "'Orbitron', monospace",
    fontSize: '0.65rem', letterSpacing: '1px',
    cursor: 'pointer', transition: 'all 0.2s',
  },
  toggleActive: {
    background: 'rgba(0,245,255,0.1)', color: '#00f5ff',
    boxShadow: 'inset 0 0 0 1px rgba(0,245,255,0.2)',
  },

  scoreHero: {
    display: 'flex', gap: '36px', alignItems: 'center',
    padding: '28px', background: 'rgba(255,255,255,0.02)',
    border: '1px solid rgba(255,255,255,0.06)',
    borderRadius: '16px',
  },
  scoreRing: {
    width: '130px', height: '130px', minWidth: '130px',
    borderRadius: '50%', border: '4px solid',
    display: 'flex', flexDirection: 'column',
    alignItems: 'center', justifyContent: 'center',
    transition: 'all 0.5s',
  },
  scoreNum: {
    fontFamily: "'Orbitron', monospace",
    fontSize: '1.8rem', fontWeight: '900',
  },
  scoreLabel: {
    fontFamily: "'Orbitron', monospace",
    fontSize: '0.5rem', letterSpacing: '1px', marginTop: '4px',
  },
  scoreMeta: { flex: 1 },
  metaTitle: {
    fontFamily: "'Orbitron', monospace",
    fontSize: '0.85rem', color: 'white', marginBottom: '10px',
  },
  progressBar: {
    height: '6px', background: 'rgba(255,255,255,0.06)',
    borderRadius: '3px', marginTop: '16px', overflow: 'hidden',
  },
  progressFill: { height: '100%', borderRadius: '3px', transition: 'width 1s ease' },
  grid: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' },
  card: {
    padding: '24px', background: 'rgba(255,255,255,0.02)',
    border: '1px solid rgba(255,255,255,0.06)', borderRadius: '14px',
  },
  cardTitle: {
    fontFamily: "'Orbitron', monospace",
    fontSize: '0.75rem', letterSpacing: '1px', marginBottom: '16px',
  },
  tagRow: { display: 'flex', flexWrap: 'wrap', gap: '8px' },
  tag: {
    padding: '4px 12px', background: 'rgba(255,255,255,0.04)',
    border: '1px solid', borderRadius: '20px', fontSize: '0.8rem',
  },
  feedbackList: {
    listStyle: 'none', padding: 0, margin: 0,
    display: 'flex', flexDirection: 'column', gap: '10px',
  },
  feedbackItem: { display: 'flex', gap: '10px', alignItems: 'flex-start' },
  bullet: {
    color: '#00f5ff', fontSize: '1.2rem',
    lineHeight: 1.4, fontWeight: '700', minWidth: '12px',
  },
  empty: { color: '#475569', fontSize: '0.9rem', fontStyle: 'italic' },
};

// ── Score Breakdown panel styles ──────────────────────────────
const dim = {
  panel: {
    padding: '24px 28px',
    background: 'rgba(255,255,255,0.02)',
    border: '1px solid rgba(255,255,255,0.07)',
    borderRadius: '16px',
  },
  header: {
    display: 'flex', justifyContent: 'space-between',
    alignItems: 'center', marginBottom: '20px',
  },
  title: {
    fontFamily: "'Orbitron', monospace",
    fontSize: '0.75rem', letterSpacing: '1.5px',
    color: 'white', margin: 0,
  },
  compositeBadge: {
    padding: '4px 12px',
    border: '1px solid',
    borderRadius: '20px',
    fontFamily: "'Orbitron', monospace",
    fontSize: '0.65rem', fontWeight: '700',
    letterSpacing: '1px',
  },
  barsContainer: {
    display: 'flex', flexDirection: 'column', gap: '14px',
  },
  row: {
    display: 'flex', alignItems: 'center', gap: '12px',
  },
  labelCol: {
    width: '150px', minWidth: '150px',
    display: 'flex', flexDirection: 'column', gap: '2px',
  },
  label: {
    color: '#e2e8f0',
    fontFamily: "'Rajdhani', sans-serif",
    fontSize: '0.88rem', fontWeight: '600',
  },
  desc: {
    color: '#475569', fontSize: '0.72rem', lineHeight: 1.4,
  },
  barCol: {
    flex: 1,
  },
  track: {
    height: '10px',
    background: 'rgba(255,255,255,0.06)',
    borderRadius: '5px',
    overflow: 'hidden',
  },
  fill: {
    height: '100%',
    borderRadius: '5px',
    transition: 'width 1.2s cubic-bezier(0.4, 0, 0.2, 1)',
    minWidth: '2px',
  },
  pct: {
    width: '44px', minWidth: '44px',
    fontFamily: "'Orbitron', monospace",
    fontSize: '0.75rem', fontWeight: '700',
    textAlign: 'right',
  },
  tip: {
    marginTop: '16px',
    padding: '12px 16px',
    background: 'rgba(245,158,11,0.06)',
    border: '1px solid rgba(245,158,11,0.15)',
    borderRadius: '10px',
    color: '#94a3b8',
    fontSize: '0.84rem',
    lineHeight: 1.6,
  },
};
