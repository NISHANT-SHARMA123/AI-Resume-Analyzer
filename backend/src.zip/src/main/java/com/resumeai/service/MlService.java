package com.resumeai.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.*;

/**
 * MlService — communicates with the Python ML microservice
 *
 * ARCHITECTURE:
 *   React Frontend → Spring Boot (Java) → Python Flask ML Service
 *
 * WHY A SEPARATE PYTHON SERVICE?
 *   Java does not have great NLP/ML libraries.
 *   Python has spaCy, scikit-learn, TF-IDF, etc.
 *   So we use Python for the AI work and Java for the web layer.
 *
 * ENDPOINTS CALLED:
 *   POST /analyze                 — Resume vs JD analysis (existing)
 *   POST /generate-improved-resume — AI-optimized structured resume (NEW)
 */
@Service
public class MlService {

    @Value("${ml.service.url}")
    private String mlServiceUrl;

    private final RestTemplate restTemplate = new RestTemplate();

    // ═══════════════════════════════════════════
    //  EXISTING: analyzeResume
    // ═══════════════════════════════════════════
    @SuppressWarnings("unchecked")
    public Map<String, Object> analyzeResume(String resumeText, String jobDescription) {
        try {
            Map<String, String> requestBody = new HashMap<>();
            requestBody.put("resume_text", resumeText);
            requestBody.put("job_description", jobDescription);

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<Map<String, String>> request = new HttpEntity<>(requestBody, headers);

            ResponseEntity<Map> response = restTemplate.exchange(
                mlServiceUrl + "/analyze",
                HttpMethod.POST,
                request,
                Map.class
            );

            return response.getBody();

        } catch (Exception e) {
            System.err.println("ML Service error: " + e.getMessage());
            return getFallbackAnalysis(resumeText, jobDescription);
        }
    }

    // ═══════════════════════════════════════════
    //  NEW: generateImprovedResume
    //
    //  Calls the Python /generate-improved-resume endpoint.
    //  Returns a structured map the ImprovedResumeGeneratorService
    //  uses to build the DOCX.
    //
    //  Expected response fields from Python:
    //    candidateName      String
    //    professionalSummary String
    //    skills             List<String>
    //    experience         List<{title,company,period,bullets[]}>
    //    education          List<{degree,institution,year}>
    //    improvements       List<String>   (AI-applied changes)
    // ═══════════════════════════════════════════
    @SuppressWarnings("unchecked")
    public Map<String, Object> generateImprovedResume(
            String resumeText,
            String jobDescription,
            String missingKeywords,
            String suggestions) {
        try {
            Map<String, String> requestBody = new HashMap<>();
            requestBody.put("resume_text",     resumeText);
            requestBody.put("job_description", jobDescription != null ? jobDescription : "");
            requestBody.put("missing_keywords",missingKeywords != null ? missingKeywords : "");
            requestBody.put("suggestions",     suggestions != null ? suggestions : "");

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<Map<String, String>> request = new HttpEntity<>(requestBody, headers);

            ResponseEntity<Map> response = restTemplate.exchange(
                mlServiceUrl + "/generate-improved-resume",
                HttpMethod.POST,
                request,
                Map.class
            );

            Map<String, Object> body = response.getBody();
            return body != null ? body : getFallbackImprovedResume(resumeText, missingKeywords);

        } catch (Exception e) {
            System.err.println("ML Service /generate-improved-resume error: " + e.getMessage());
            return getFallbackImprovedResume(resumeText, missingKeywords);
        }
    }

    // ═══════════════════════════════════════════
    //  FALLBACK: Basic analysis when ML is down
    // ═══════════════════════════════════════════
    private Map<String, Object> getFallbackAnalysis(String resumeText, String jobDescription) {
        Map<String, Object> result = new HashMap<>();

        String[] jdWords = jobDescription.toLowerCase().split("\\W+");
        String resumeLower = resumeText.toLowerCase();

        StringBuilder matched = new StringBuilder();
        StringBuilder missing = new StringBuilder();
        int matchCount = 0;

        for (String word : jdWords) {
            if (word.length() > 3) {
                if (resumeLower.contains(word)) {
                    if (matched.length() > 0) matched.append(",");
                    matched.append(word);
                    matchCount++;
                } else {
                    if (missing.length() > 0) missing.append(",");
                    missing.append(word);
                }
            }
        }

        double score = jdWords.length > 0
            ? Math.min(100.0, (matchCount * 100.0) / Math.max(1, jdWords.length))
            : 50.0;

        result.put("matchScore", Math.round(score * 10.0) / 10.0);
        result.put("keywordsMatched", matched.toString());
        result.put("missingKeywords", missing.toString());
        result.put("feedbackPoints",
            "- Resume has been analyzed with basic keyword matching\n" +
            "- Connect the Python ML service for detailed AI feedback\n" +
            "- Add more keywords from the job description to improve your score");
        result.put("improvementSuggestions",
            "1. Start the Python ML microservice for AI-powered analysis\n" +
            "2. Add quantifiable achievements to your resume\n" +
            "3. Tailor your skills section to match the job description");
        result.put("summary", "Resume analyzed with basic keyword matching. " +
            "Please start the Python ML service for full AI analysis.");

        return result;
    }

    /**
     * Fallback improved resume when ML service is unavailable.
     * Generates a minimal structured response from raw resume text.
     */
    private Map<String, Object> getFallbackImprovedResume(String resumeText, String missingKeywords) {
        Map<String, Object> result = new HashMap<>();
        result.put("candidateName", "Candidate");
        result.put("professionalSummary",
            "Experienced professional seeking to leverage skills and experience in a challenging new role. " +
            "Demonstrated ability to deliver results in fast-paced environments.");

        // Build skills list from missing keywords + some generic ones
        List<String> skills = new ArrayList<>();
        if (missingKeywords != null && !missingKeywords.isBlank()) {
            for (String kw : missingKeywords.split(",")) {
                String trimmed = kw.trim();
                if (!trimmed.isEmpty()) skills.add(trimmed);
            }
        }
        if (skills.isEmpty()) {
            skills.addAll(Arrays.asList("Communication", "Problem-Solving", "Team Collaboration",
                    "Project Management", "Analytical Thinking"));
        }
        result.put("skills", skills);

        // Minimal experience placeholder
        Map<String, Object> job = new HashMap<>();
        job.put("title", "Professional Role");
        job.put("company", "Company Name");
        job.put("period", "Year – Present");
        job.put("bullets", Arrays.asList(
            "Delivered key projects on time, meeting all stakeholder requirements",
            "Collaborated cross-functionally to drive process improvements",
            "Utilized data-driven insights to inform decision making"
        ));
        result.put("experience", List.of(job));
        result.put("education", List.of());

        result.put("improvements", Arrays.asList(
            "ML service was unavailable — this is a template resume. Start the Python service for AI optimization.",
            "Add your actual work experience, education, and skills.",
            "Tailor the professional summary to the target job description."
        ));

        return result;
    }
}
